package com.example.mindmixpuzzle;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    static class Puzzle {
        String type, mm, en, answer, hint, explanation;
        Puzzle(String t,String m,String e,String a,String h,String x){type=t;mm=m;en=e;answer=a.toLowerCase(Locale.ROOT);hint=h;explanation=x;}
    }
    final ArrayList<Puzzle> puzzles = new ArrayList<>();
    int index=0, score=0, streak=0;
    boolean myanmar=true, answered=false;
    LinearLayout root, card;
    TextView title, category, question, feedback, scoreView, hintView;
    EditText answerInput;
    Button checkBtn, hintBtn, nextBtn, langBtn;
    int purple=Color.rgb(91,55,160), ink=Color.rgb(35,31,48);

    @Override public void onCreate(Bundle b){super.onCreate(b); seed(); build(); showPuzzle();}
    void seed(){
        puzzles.add(new Puzzle("NUMBER / ကိန်းဂဏန်း","နောက်ကိန်းဂဏန်းက ဘာလဲ?\n2, 6, 12, 20, 30, ?","What comes next?\n2, 6, 12, 20, 30, ?","42","ကွာခြားချက်တွေကို ကြည့်ပါ။ / Check the gaps.","ပေါင်းတာက 4, 6, 8, 10, 12 ဖြစ်လို့ 30 + 12 = 42။"));
        puzzles.add(new Puzzle("RIDDLE / ဉာဏ်စမ်း","ငါ့မှာ မြို့တွေရှိတယ်၊ အိမ်မရှိဘူး။ မြစ်တွေရှိတယ်၊ ရေမရှိဘူး။ ငါဘာလဲ?","I have cities but no houses, rivers but no water. What am I?","map","နေရာတွေကို ပုံဖော်ပြထားတာပါ။ / It shows places.","မြေပုံ (Map) ဖြစ်ပါတယ်။"));
        puzzles.add(new Puzzle("LOGIC / ယုတ္တိ","ပြိုင်ပွဲမှာ ဒုတိယလူကို ကျော်တက်လိုက်ရင် ကိုယ်က ဘယ်နေရာရောက်မလဲ?","If you overtake the person in 2nd place, what place are you in?","2","ပထမနေရာမဟုတ်သေးပါ။ / Not first.","ဒုတိယလူရဲ့နေရာကို ယူတာမို့ ဒုတိယပါ။"));
        puzzles.add(new Puzzle("TRICK / လှည့်ကွက်","တစ်နှစ်မှာ လဘယ်နှလမှာ ၂၈ ရက်ရှိသလဲ?","How many months have 28 days?","12","၂၈ ရက်ထက် ပိုရှိနိုင်သလား? / Can a month have more?","လတိုင်းမှာ အနည်းဆုံး ၂၈ ရက်ရှိပါတယ်။"));
        puzzles.add(new Puzzle("NUMBER / ကိန်းဂဏန်း","ကိန်းစဉ်ကို ဖြည့်ပါ။ 1, 1, 2, 3, 5, 8, ?","Complete the sequence: 1, 1, 2, 3, 5, 8, ?","13","ရှေ့က ကိန်းနှစ်ခုကို ပေါင်းပါ။ / Add the previous two numbers.","Fibonacci sequence ဖြစ်ပြီး 5 + 8 = 13။"));
        puzzles.add(new Puzzle("RIDDLE / ဉာဏ်စမ်း","အသံမထွက်ဘဲ ပြန်ဖြေတတ်တယ်။ ကိုယ်ပြောတာကိုပဲ ပြန်ပြောတယ်။ ဘာလဲ?","I can answer without speaking and repeat what you say. What am I?","echo","တောင်ကြားမှာ ကြားရတတ်တယ်။ / Often heard in valleys.","ပဲ့တင်သံ (Echo) ဖြစ်ပါတယ်။"));
        puzzles.add(new Puzzle("LOGIC / ယုတ္တိ","ကြက် ၅ ကောင်က ဥ ၅ လုံးကို ၅ ရက်မှာ ဥတယ်။ ကြက် ၁ ကောင်က ဥ ၁ လုံးကို ဘယ်နှရက်မှာ ဥမလဲ?","5 hens lay 5 eggs in 5 days. How many days for 1 hen to lay 1 egg?","5","ကြက်တစ်ကောင်ရဲ့နှုန်းကို စဉ်းစားပါ။ / Work out one hen's rate.","ကြက်တစ်ကောင်က ၅ ရက်မှာ ဥတစ်လုံး ဥပါတယ်။"));
        puzzles.add(new Puzzle("TRICK / လှည့်ကွက်","လျှပ်စစ်ရထားတစ်စင်းက မြောက်ဘက်ကို သွားနေတယ်။ မီးခိုးက ဘယ်ဘက်ကို လွင့်မလဲ?","An electric train travels north. Which way does its smoke blow?","none","လျှပ်စစ်ရထားမှာ မီးခိုးရှိသလား? / Does it make smoke?","လျှပ်စစ်ရထားမို့ မီးခိုးမထွက်ပါဘူး။"));
        Collections.shuffle(puzzles);
    }
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.CENTER);return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(22,28,22,20);root.setBackgroundColor(Color.rgb(247,244,252));
        ScrollView scroll=new ScrollView(this); LinearLayout content=new LinearLayout(this);content.setOrientation(1);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        title=text("MINDMIX",25,purple,true);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        langBtn=button("မြန်မာ / EN");top.addView(langBtn);content.addView(top);
        TextView sub=text("THINK DIFFERENT • စဉ်းစားကြည့်ပါ",12,Color.GRAY,true);content.addView(sub);
        scoreView=text("",15,ink,true);scoreView.setPadding(0,18,0,14);content.addView(scoreView);
        card=new LinearLayout(this);card.setOrientation(1);card.setPadding(20,24,20,20);card.setBackground(bg(Color.WHITE,28));card.setElevation(5);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,8,0,14);content.addView(card,cp);
        category=text("",13,purple,true);card.addView(category);
        question=text("",21,ink,true);question.setPadding(0,24,0,24);card.addView(question);
        answerInput=new EditText(this);answerInput.setSingleLine(true);answerInput.setTextSize(17);answerInput.setHint("Your answer / အဖြေ");answerInput.setPadding(16,10,16,10);answerInput.setBackground(bg(Color.rgb(245,242,250),18));card.addView(answerInput,new LinearLayout.LayoutParams(-1,-2));
        checkBtn=button("CHECK / အဖြေစစ်မယ်");hintBtn=button("HINT / အရိပ်အမြွက်");nextBtn=button("NEXT PUZZLE / နောက်တစ်ပုဒ်");
        feedback=text("",16,ink,true);feedback.setPadding(4,18,4,8);card.addView(feedback);
        hintView=text("",14,Color.GRAY,false);card.addView(hintView);
        content.addView(checkBtn);content.addView(hintBtn);content.addView(nextBtn);
        TextView foot=text("No internet needed • Offline puzzle game",11,Color.GRAY,false);foot.setPadding(0,18,0,0);content.addView(foot);
        setContentView(root);
        langBtn.setOnClickListener(v->{myanmar=!myanmar;showPuzzle();});
        checkBtn.setOnClickListener(v->check());
        hintBtn.setOnClickListener(v->{hintView.setText(puzzles.get(index).hint);});
        nextBtn.setOnClickListener(v->{index=(index+1)%puzzles.size();answered=false;answerInput.setText("");feedback.setText("");hintView.setText("");showPuzzle();});
    }
    void showPuzzle(){
        Puzzle p=puzzles.get(index);
        category.setText(p.type+"     •     "+(index+1)+" / "+puzzles.size());
        question.setText(myanmar?p.mm:p.en);
        scoreView.setText((myanmar?"အမှတ်: ":"SCORE: ")+score+"     "+(myanmar?"ဆက်တိုက်မှန်: ":"STREAK: ")+streak);
        langBtn.setText(myanmar?"မြန်မာ / EN":"EN / မြန်မာ");
        checkBtn.setText(myanmar?"အဖြေစစ်မယ်":"CHECK ANSWER");
        hintBtn.setText(myanmar?"အရိပ်အမြွက်":"HINT");
        nextBtn.setText(myanmar?"နောက်တစ်ပုဒ်":"NEXT PUZZLE");
        answerInput.setHint(myanmar?"အဖြေရေးပါ":"Type your answer");
    }
    void check(){
        if(answered)return;
        String a=answerInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        if(a.isEmpty()){answerInput.setError(myanmar?"အဖြေရေးပါ":"Enter an answer");return;}
        Puzzle p=puzzles.get(index);
        if(a.equals(p.answer)){
            score+=10;streak++;feedback.setText(myanmar?"မှန်ပါတယ်! +10 အမှတ် 🎉\n":"Correct! +10 points 🎉\n");
        }else{
            streak=0;feedback.setText((myanmar?"မမှန်သေးပါ။ အဖြေ: ":"Not quite. Answer: ")+p.answer+"\n");
        }
        feedback.append(myanmar?p.explanation:p.explanation);
        answered=true;scoreView.setText((myanmar?"အမှတ်: ":"SCORE: ")+score+"     "+(myanmar?"ဆက်တိုက်မှန်: ":"STREAK: ")+streak);
    }
}
