# MindMix Puzzle (Android)

A bilingual Myanmar + English puzzle game starter project for Android Studio.

## Features
- Mixed puzzles: riddles, number patterns, logic, and trick questions
- Myanmar / English toggle
- Three difficulty levels internally; starts at Normal
- Hint button, answer checking, score, streak, and next puzzle
- Offline question bank

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.

Package: `com.example.mindmixpuzzle`
Minimum SDK: 23 (Android 6.0)

This is source code, not a prebuilt APK. Android Studio is needed to compile it.
